#NAME
Daisy - The app that helps you create healthier and more productive habits.

#SUMMARY
Create good habits effectively, using established psychology, to improve yourself. Schedule any type of repeating task that you want to turn into a new habit. Track your progress and analyze your habit formation goals.

#FEATURES
+ Established around the latest research on habit formation.
+ Simple and pretty UI highlights what you need to do when.
+ Intelligent notifications remind you when you haven't completed scheduled tasks, based on your app usage patterns.
+ Points, sounds and graphics help to reinforce your habit creation.
+ Beautiful charts display your progress in detail and assist you in analyzing your achievements.

#DESCRIPTION
Create any task for any day
Do you want to learn a new language? Exercise more? Daisy enables you to create and schedule any type of repeating task. She will remind you what to do on what day so that you don't have to think about it.

Build habits using simple psychology
Daisy is established around the latest research on habit formation. Routines will help you turn repeating tasks into good habits; cues and rewards will make the process effective and fun. Minor tasks in your daily schedule will turn into major changes in your life.

Engage in your progress
By completing tasks you earn points that help you track your progress and keep you motivated. Daisy creates beautiful points charts for you, which you can use to analyze and adjust your habit formation goals so that they best fit in with your daily life.

#AVAILABILITY
For iPhone only with iOS 9.0 and newer.

#CONTACT
Email
hi@daisyapp.xyz

Website
http://daisyapp.xyz/