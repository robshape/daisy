#NAME
Daisy - Create Healthy and Productive Habits

#SUMMARY
Daisy helps you create good habits effectively, using established psychology, to improve yourself. Schedule any type of repeating task that you want to turn into a new habit. Use Daisy to form new habits while tracking your progress and analyzing your habit formation goals.

#FEATURES
+ Established around the latest research on habit formation.
+ Simple and pretty user interface highlights what you need to do when.
+ Intelligent notifications remind you when you haven't completed scheduled tasks, based on your app usage patterns.
+ Points, sounds, and visuals help to reinforce your habit creation.
+ Beautiful charts display your progress in detail and assist you in analyzing your achievements.

#DESCRIPTION
Create any task for any day
Do you want to learn a new language? Exercise more? Daisy enables you to create and schedule any type of repeating task. She will remind you what to do on what day so that you don't have to think about it. Working on something every day helps you form a new habit.

Build habits using simple psychology
Daisy is established around the latest research on habit formation. Routines will help you turn repeating tasks into good habits; cues and rewards will make the process effective and fun. Minor tasks in your daily schedule will turn into major changes in your life.

Engage in your progress
By completing tasks you earn points that help you track your progress and keep you motivated. Daisy creates beautiful charts for you, which you can use to analyze and adjust your habit formation goals so that they best fit in with your daily life.

#AVAILABILITY
Requires iOS 9.0 or later. Compatible with iPhone, iPad, and iPod touch.
Free (contains in-app purchases).
https://itunes.apple.com/app/id1099509808/

#CONTACT
Email
hi@shapeless.xyz

Website
https://daisy.shapeless.xyz/
